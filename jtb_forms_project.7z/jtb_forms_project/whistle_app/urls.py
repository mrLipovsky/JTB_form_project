from django.urls import path
from . import views

urlpatterns = [ 
    path( '', views.whistle_form_view, name='whistle_form_')

]