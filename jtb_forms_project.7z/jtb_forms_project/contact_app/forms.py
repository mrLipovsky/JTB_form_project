from django import forms
from django.core import validators
from django.core.validators import RegexValidator

class ContactForm(forms.Form):
    name = forms.CharField(label='form__input', 
            max_length=20,
            widget=forms.TextInput(attrs={'placeholder':'Jméno a příjmení / Název firmy*',
                                          'class':'form__input',  
                                          'id':'input-name',
                                          'name':'name', 
                                          'type':'type'}))
    email = forms.EmailField(label='email',
            max_length=20,
            widget=forms.EmailInput(attrs={'placeholder':'E-mail*',
                                           'class':'form__input', 
                                           'id':'input-email',
                                           'name':'email', 
                                           'type':'email'}))
    
    phone = forms.CharField(label='phone',validators = [RegexValidator(regex = r"")],
            widget=forms.TextInput(attrs={'placeholder':'Telefon*',
                                          'class':'form__input', 
                                          'id':'input-phone',
                                          'name':'tel', 
                                          'type':'tel'}))
    
    message = forms.CharField(label='Message', 
            widget=forms.Textarea(attrs={'placeholder':'Chcete nám něco sdělit?',
                                         'class':'form__input form__input--textarea', 
                                         'id':'input-message', 
                                         'name':'message',
                                         'aria-describedby':'input-message-hint'}))
    
    def clean(self):
        all_clean_data = super().clean()
        name = all_clean_data['name']   
        email = all_clean_data['email']
        phone = all_clean_data['phone']
        message = all_clean_data['message']
