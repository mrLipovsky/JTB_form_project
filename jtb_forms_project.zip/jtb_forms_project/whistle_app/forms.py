from django import forms

class WhistleForm(forms.Form):
    message = forms.CharField(label='Message', 
            widget=forms.Textarea(attrs={'placeholder':'Chcete nám něco sdělit?','class':'form__input form__input--textarea', 'id':'input-message', 'aria-describedby':'input-message-hint'}))
    
    def clean(self):
        all_clean_data = super().clean()
        message = all_clean_data['message']
