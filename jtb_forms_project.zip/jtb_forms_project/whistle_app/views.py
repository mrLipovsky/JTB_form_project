
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from . import forms


def whistle_form_view(request):
    form = forms.WhistleForm()
    if request.method == 'POST':
        message = request.POST.get('message')
        
        data  = {
           'message' : message,
        }

         #send email 
        send_mail('neco', message, data, [email@email.com])
    
    return render(request, 'whistle_app/index.html', {'form': form})     
