from django.shortcuts import render, redirect
from django.core.mail import send_mail
from . import forms


def whistle_form_view(request):
    form = forms.WhistleForm()
    if request.method == 'POST':
        message = request.POST.get('message')
        
        data  = {
           'message' : message,
        }

        subject = 'Oznámeni - Whistleblower'
        message_email_body = f'Dobrý deň, oznámení: {data}. ďakujem'
        
    
        #send email (subject, message, email from, email to)
        send_mail(subject, message_email_body, setting.EMAIL_HOST_USER, [email])
    
    return render(request, 'whistle_app/index.html', {'form': form})     
