from django import forms

class WhistleForm(forms.Form):
    message_text = forms.CharField(label='Message_text', 
            widget=forms.Textarea(attrs={'placeholder':'Vaše oznámení',
                                         'class':'form__input form__input--textarea', 
                                         'id':'input-message', 
                                         'name':'message',
                                         'aria-describedby':'input-message-hint'}))
    
    def clean(self):
        all_clean_data = super().clean()
        message_text = all_clean_data['message_text']
