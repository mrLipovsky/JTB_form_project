from django.shortcuts import render, redirect
from django.core.mail import send_mail
from . import forms

# Create your views here.


# def index(request):
#     return render(request, 'whistle_form/index.html')

# def whistle_form_view(request):
#     form = forms.WhistleForm()
#     if request.method == 'POST':
#         name = request.POST.get('name')
#         phone = request.POST.get('phone')
#         email = request.POST.get('email')
#         message = request.POST.get('message')
#         ctx = {
#            'name' : name,
#            'message' : message, 
#            'phone' : phone, 
#            'email' : email,
#         }
#         message = render_to_string('whistle_form/index.html', ctx)
#         # ?recipient = form.cleaned_data.get('email'),
#         send_mail(name, phone, email, message,
#         settings.EMAIL_HOST_USER,
#         # [recipient], 
#         fail_silently=False)

#     return render(request, 'whistle_form/index.html', {'form': form})

# def whistle_form_view(request):
#     form = forms.WhistleForm()
#     if request.method == 'POST':
#         form = forms.WhistleForm(request.POST)
#         if form.is_valid():
#             subject = 'Code Band'
#             message = 'Sending Email through Gmail'
#             recipient = form.cleaned_data.get('email')
#             send_mail(subject, message, recipient, fail_silently=False)
#         return redirect('whistle_form/index.html')
#     return render(request, 'whistle_form/index.html', {'form': form})

def contact_form_view(request):
    form = forms.ContactForm()
    if request.method == 'POST':
        name = request.POST.get('name') 
        email = request.POST.get('email') 
        phone = request.POST.get('phone')
        message = request.POST.get('message') 
        data  = {
           'name' : name,
           'message' : message, 
           'phone' : phone, 
           'email' : email,
        }
        
        subject = 'Kontakt - sdělení'
        message_email_body = f'Dobrý deň, kontaktné údaje: {data}. Prosím kontaktuje uživateľa.'
        
    
        #send email (subject, message, email from, email to)
        send_mail(subject, message_email_body, setting.EMAIL_HOST_USER, [data.email])
    
    return render(request, 'contact_app/index.html', {'form': form})     
